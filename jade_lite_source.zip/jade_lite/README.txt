JADE LITE (Horizon, API 0.1)

Build (can may co Rust, khong build duoc tren dien thoai):
  rustup target add wasm32-unknown-unknown
  cargo install --git https://github.com/ludovic111/horizon cargo-horizon-mod
  cargo horizon-mod new jade_lite
  # chep de: src/lib.rs, src/api.rs, horizon-mod.toml vao thu muc jade_lite/
  cd jade_lite
  cargo horizon-mod build        # -> target/horizon-mod/jade_lite.hmod
  cargo horizon-mod check target/horizon-mod/jade_lite.hmod

Cai: chep jade_lite.hmod vao thu muc horizon-mods/ canh options.txt,
roi bat trong Options > Mods. Go /jade de bat/tat panel.

Neu build bao loi kieu: chi sua 3 ham trong src/api.rs.

KHONG CO MAY TINH (build bang GitHub):
  1. Tao repo moi tren github.com, upload toan bo thu muc nay (gom ca .github/).
  2. Tab Actions > build-hmod > chay xong > tai artifact "jade_lite_hmod".
  3. Giai nen lay jade_lite.hmod, chep vao horizon-mods/.
  Neu job do bao loi kieu o src/api.rs, gui noi dung loi cho Claude de sua.
