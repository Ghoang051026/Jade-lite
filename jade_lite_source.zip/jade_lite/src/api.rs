//! Lớp bọc quanh API `world` của Horizon.
//!
//! Đây là CHỖ DUY NHẤT dùng `horizon_mod_sdk::world`. Tài liệu chỉ nói
//! `raycast(distance)` trả "block đầu tiên theo hướng nhìn" và engine có
//! `world.get-block`, `world.get-biome`; kiểu trả về chính xác nằm trong
//! `crates/horizon-mod-sdk/wit/horizon.wit`. Nếu `cargo horizon-mod build`
//! báo lỗi kiểu, chỉ cần sửa 3 hàm dưới đây, phần còn lại không đổi.

use horizon_mod_sdk::world;

/// Toạ độ block đang nhìn.
#[derive(Clone, Copy, PartialEq, Eq)]
pub struct Target {
    pub x: i32,
    pub y: i32,
    pub z: i32,
}

/// Block đầu tiên theo hướng nhìn trong `distance` block.
pub fn target(distance: f64) -> Option<Target> {
    // Giả định: raycast -> Option<hit>, hit có block_x/block_y/block_z.
    let hit = world::raycast(distance)?;
    Some(Target {
        x: hit.block_x as i32,
        y: hit.block_y as i32,
        z: hit.block_z as i32,
    })
}

/// ID registry của block, ví dụ `minecraft:oak_log`.
pub fn block_id(t: Target) -> Option<String> {
    // Giả định: get_block(x, y, z) -> Option<String>.
    world::get_block(t.x, t.y, t.z)
}

/// ID biome tại block, ví dụ `minecraft:plains`.
pub fn biome(t: Target) -> Option<String> {
    // Giả định: get_biome(x, y, z) -> Option<String>.
    world::get_biome(t.x, t.y, t.z)
}
